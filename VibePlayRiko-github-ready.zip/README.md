# VibePlay – Riko — Build & Config Scaffold

`com.rikodev.music` · React Native + Expo (SDK 51) · Expo Router · TypeScript

This bundle contains **every build/config/asset/theme/env file** needed to build and
export an Android **APK** (preview) or **AAB** (production) with **Expo EAS**.
It is designed to drop into your existing, already-complete VibePlay codebase
**without overwriting your features**.

## What's included

```
vibeplay-riko/
├─ app.config.ts         # dynamic Expo config (name, package, perms, plugins, splash)
├─ eas.json              # EAS build profiles: development / preview(APK) / production(AAB)
├─ package.json          # pinned SDK-51 dependency set + build scripts
├─ tsconfig.json         # strict TS + "@/*" path alias
├─ babel.config.js       # babel-preset-expo + module-resolver + reanimated plugin
├─ metro.config.js       # adds audio asset extensions
├─ expo-env.d.ts         # Expo + typed-routes types
├─ .env.example          # public env vars + EAS_PROJECT_ID
├─ .gitignore / .easignore
├─ app/_layout.tsx       # root navigation + providers (MERGE if you already have one)
├─ src/
│  ├─ config/env.ts       # typed runtime config
│  ├─ theme/              # Material 3 Light-Blue palette + Light Neon Glass tokens
│  └─ components/         # GlassSurface + GlassButton primitives
└─ assets/
   ├─ icon.png (1024)            │ adaptive-icon.png (1024)
   ├─ splash-icon.png (1024)     │ notification-icon.png (96)
   ├─ favicon.png (48)
   ├─ fonts/              # drop your .ttf files here
   └─ _src/               # editable SVG sources + scripts/render-assets.mjs
```

## Color identity

Material 3, light background, **Light Blue** primary (`#1565C0`) with colourful
accents (cyan / mint / pink / violet). The Light Neon Glass layer (`src/theme/glass.ts`)
is layered **on top** of these brand colors — it never replaces them.

## Setup

```bash
npm install
npm install -g eas-cli      # if not already installed
eas login
eas init                    # creates/links the EAS project, writes the projectId
```

Set your EAS project id (so app.config.ts picks it up):

```bash
cp .env.example .env        # then edit EAS_PROJECT_ID, or rely on "eas init"
```

## Build Android

```bash
# Installable APK (internal testing)
npm run build:apk           # eas build -p android --profile preview

# Play Store bundle (AAB)
npm run build:aab           # eas build -p android --profile production

# Dev client (for native modules like media-library / DSP)
npm run build:dev
```

## Regenerate icons

Edit the SVGs in `assets/_src/`, then:

```bash
node scripts/render-assets.mjs
```

## Important notes

- This project uses native modules (`expo-media-library`, `expo-av`, audio DSP),
  so it runs as an **Expo Dev Client / prebuild** — not Expo Go.
- `newArchEnabled: true` is set; flip to `false` in `app.config.ts` if any native
  dependency is not yet New-Architecture compatible.
- If you already have `app/_layout.tsx`, merge the providers from the included one
  instead of replacing your routes.
